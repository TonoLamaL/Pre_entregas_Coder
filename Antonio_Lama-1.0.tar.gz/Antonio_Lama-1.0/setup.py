from setuptools import setup

setup(

    name = 'Antonio_Lama',
    version = '1.0',
    description= 'Pre entrega 1 y 2',
    author= 'Antonio Lama',
    author_email= 'alama@ebackexpress.cl',

    packages = ['Antonio_Lama', 'Antonio_Lama.Primera_pre_entrega','Antonio_Lama.Segunda_pre_entrega' ]


)

