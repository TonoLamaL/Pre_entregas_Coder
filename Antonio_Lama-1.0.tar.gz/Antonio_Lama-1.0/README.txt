TOÑO!

debes instalar elpaquete antes de usar el main.

transporfar paquete.-> 
1.- primero hacer los paquetes
2.- en la terminal posicionarte donde esta el setup
3.- llamar -> python setup.py sdist
4.- listo

el paquete a usar se llama Antonio_Lama-1.0 y esta en careta dist en path /Users/tonolama/Documents/Coderbeca_python/Proyecto_final_AntonioLama/dist


para instalar
1.- path de carpeta dist del paquete en terminal
2.- pip3 install + Antonio_Lama-1.0.tar.gz
3.- listo

para desintalar
1.- en terminal pip3 uninstall Antonio_Lama
2.- listo